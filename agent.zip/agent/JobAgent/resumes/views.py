from django.shortcuts import render
from django.contrib.auth.decorators import login_required

from .models import Resume

from ai_agents.gemini_service import analyze_resume

from .resume_analyzer import (
    extract_education,
    extract_projects,
    extract_experience
)
from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from ai_agents.ats_checker import calculate_ats_score
from .forms import ResumeForm


@login_required
def upload_resume(request):

    if request.method == "POST":

        form = ResumeForm(
            request.POST,
            request.FILES
        )

        if form.is_valid():

            resume = form.save(
                commit=False
            )

            resume.user = request.user

            resume.save()

            return redirect(
                "resume_summary"
            )

    else:

        form = ResumeForm()

    return render(
        request,
        "resumes/upload_resume.html",
        {
            "form": form
        }
    )


@login_required
def resume_summary(request):

    resume = Resume.objects.filter(
        user=request.user
    ).last()

    if not resume:

        return render(
            request,
            "resumes/summary.html",
            {
                "resume": None,
                "ai_analysis": "No resume uploaded."
            }
        )

    ats_score, ats_feedback = calculate_ats_score(
        resume.resume_text
    )

    education = extract_education(
        resume.resume_text
    )

    projects = extract_projects(
        resume.resume_text
    )

    experience = extract_experience(
        resume.resume_text
    )

    print("EDUCATION:", education)
    print("PROJECTS:", projects)
    print("EXPERIENCE:", experience)

    ai_analysis = analyze_resume(
        resume.resume_text
    )

    return render(
        request,
        "resumes/summary.html",
        {
            "resume": resume,
            "ai_analysis": ai_analysis,
            "education": education,
            "projects": projects,
            "experience": experience,
            "ats_score": ats_score,
            "ats_feedback": ats_feedback
        }
    )
from django.shortcuts import redirect
from django.contrib.auth.decorators import login_required


@login_required
def delete_resume(request):

    resume = Resume.objects.filter(
        user=request.user
    ).last()

    if resume:
        resume.delete()

    return redirect(
        "dashboard"
    )