from ai_agents.gemini_service import ask_gemini


def career_copilot(
    resume_text,
    job_description
):

    prompt = f"""
    Analyze the candidate and the job.

    Resume:
    {resume_text}

    Job:
    {job_description}

    Provide:

    1. Match Score (%)

    2. Strengths

    3. Missing Skills

    4. Learning Roadmap

    5. Recommended Projects

    6. Interview Questions

    7. Hiring Chances

    Keep the answer concise.
    """

    return ask_gemini(prompt)