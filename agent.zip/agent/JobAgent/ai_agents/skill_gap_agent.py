from ai_agents.gemini_service import ask_gemini


def analyze_skill_gap(
    resume_text,
    job_description
):

    prompt = f"""
    Compare the candidate resume and job description.

    Resume:
    {resume_text}

    Job Description:
    {job_description}

    Give:

    1. Match Score (%)

    2. Matched Skills

    3. Missing Skills

    4. Learning Roadmap

    5. Final Recommendation

    Keep the response clear and professional.
    """

    return ask_gemini(prompt)