from django.urls import path

from .views import (
    career_analysis,
    interview_prep,
    resume_improvement,
    resume_tailoring
)


urlpatterns = [

    path(
        "career-analysis/",
        career_analysis,
        name="career_analysis"
    ),

    path(
        "interview-prep/",
        interview_prep,
        name="interview_prep"
    ),
    path(
    "resume-tailoring/",
    resume_tailoring,
    name="resume_tailoring"
),
    path(
    "resume-improvement/",
    resume_improvement,
    name="resume_improvement"
),
]