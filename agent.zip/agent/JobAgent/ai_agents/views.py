from django.shortcuts import render

from resumes.models import Resume

from .career_copilot import (
    career_copilot
)
from .resume_tailor import (
    tailor_resume
)
from .interview_agent import (
    generate_questions,
    generate_ai_questions
)


def career_analysis(request):

    resume = Resume.objects.last()

    if not resume:

        return render(
            request,
            "ai_agents/career_analysis.html",
            {
                "analysis": "No resume uploaded."
            }
        )

    job_text = request.GET.get(
        "job_text",
        ""
    )

    analysis = career_copilot(
        resume.resume_text[:2500],
        job_text[:2500]
    )

    return render(
        request,
        "ai_agents/career_analysis.html",
        {
            "analysis": analysis
        }
    )


def interview_prep(request):

    resume = Resume.objects.last()

    if not resume:

        return render(
            request,
            "ai_agents/interview.html",
            {
                "questions": [],
                "ai_questions": "No resume uploaded."
            }
        )

    questions = generate_questions(
        resume
    )

    job_text = request.GET.get(
        "job_text",
        ""
    )

    ai_questions = generate_ai_questions(
        resume.resume_text,
        job_text
    )

    return render(
        request,
        "ai_agents/interview.html",
        {
            "questions": questions,
            "ai_questions": ai_questions
        }
    )
from .resume_improver import (
    analyze_resume_improvement
)

def resume_improvement(request):

    resume = Resume.objects.last()

    if not resume:

        return render(
            request,
            "ai_agents/resume_improvement.html",
            {
                "result": None
            }
        )

    result = analyze_resume_improvement(
        resume.resume_text
    )

    return render(
        request,
        "ai_agents/resume_improvement.html",
        {
            "result": result
        }
    )
from django.contrib.auth.decorators import (
    login_required
)

from resumes.models import Resume


@login_required
def resume_tailoring(
    request
):

    resume = Resume.objects.filter(
        user=request.user
    ).last()

    if not resume:

        return render(
            request,
            "ai_agents/resume_tailoring.html",
            {
                "result":
                "No Resume Uploaded"
            }
        )

    job_text = request.GET.get(
        "job_text",
        ""
    )

    result = tailor_resume(
        resume.resume_text[:2500],
        job_text[:2500]
    )

    return render(
        request,
        "ai_agents/resume_tailoring.html",
        {
            "result": result
        }
    )