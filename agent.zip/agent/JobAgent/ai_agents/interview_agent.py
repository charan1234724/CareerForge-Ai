from data.interview_questions import (
    QUESTION_BANK,
    HR_QUESTIONS,
    PROJECT_QUESTIONS,
    INTERNSHIP_QUESTIONS
)

from django.conf import settings
from google import genai


def generate_questions(resume):

    questions = []

    skills = [
        skill.name.lower()
        for skill in resume.skills.all()
    ]

    for skill in skills:

        if skill in QUESTION_BANK:

            skill_data = QUESTION_BANK[skill]

            if "technical" in skill_data:

                questions.extend(
                    skill_data["technical"]
                )

    text = resume.resume_text.lower()

    if "project" in text:

        questions.extend(
            PROJECT_QUESTIONS
        )

    if "intern" in text:

        questions.extend(
            INTERNSHIP_QUESTIONS
        )

    questions.extend(
        HR_QUESTIONS
    )

    return questions


def generate_ai_questions(
    resume_text,
    job_description=""
):

    try:

        client = genai.Client(
            api_key=settings.GEMINI_API_KEY
        )

        prompt = f"""
        Candidate Resume:

        {resume_text[:2000]}

        Job Description:

        {job_description[:2000]}

        Generate:

        1. Technical Questions
        2. Project Questions
        3. Internship Questions
        4. HR Questions

        Total 15 interview questions.
        """

        response = client.models.generate_content(
            model="gemini-2.0-flash",
            contents=prompt
        )

        return response.text

    except Exception:

        return """
AI Interview Generator temporarily unavailable.

Use the Resume-Based Interview Questions section instead.
"""