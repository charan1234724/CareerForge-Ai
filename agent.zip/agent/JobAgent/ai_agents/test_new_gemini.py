from google import genai

client = genai.Client(
api_key="AQ.Ab8RN6KT3Q-MKVa8lagIbZHmUkglt3CCJUf4i9pQZoRIje1njw"
)

response = client.models.generate_content(
model="gemini-2.5-flash",
contents="What is Python?"
)

print(response.text)
