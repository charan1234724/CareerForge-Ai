from google import genai
from django.conf import settings

client = genai.Client(
    api_key=settings.GEMINI_API_KEY
)

def ask_gemini(prompt):

    try:

        response = client.models.generate_content(
            model="gemini-2.0-flash",
            contents=prompt
        )

        return response.text

    except Exception as e:

        return f"""
AI service temporarily unavailable.

Error:
{str(e)}

Please try again after a few minutes.
"""

def analyze_resume(resume_text):

    prompt = f"""
    Analyze this resume and provide:

    1. Summary
    2. Strengths
    3. Weaknesses
    4. Suggested Roles

    Resume:

    {resume_text}
    """

    return ask_gemini(prompt)