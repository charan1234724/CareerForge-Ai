import requests
from django.conf import settings


def ask_llm(prompt):

    try:

        headers = {
            "Authorization":
            f"Bearer {settings.OPENROUTER_API_KEY}"
        }

        response = requests.post(

            "https://openrouter.ai/api/v1/chat/completions",

            headers=headers,

            json={

                "model":
                "deepseek/deepseek-chat",

                "messages": [

                    {
                        "role": "user",
                        "content": prompt
                    }
                ]
            }
        )

        return response.json()[
            "choices"
        ][0]["message"]["content"]

    except Exception as e:

        return (
            "AI service unavailable.\n\n"
            + str(e)
        )