CAREER_PATHS = {

    "AI Engineer": {
        "skills": [
            "python",
            "machine learning",
            "deep learning",
            "tensorflow",
            "pytorch",
            "artificial intelligence",
            "ai"
        ],


        "projects": [
            "AI Resume Analyzer",
            "AI Interview Coach",
            "RAG Chatbot",
            "Medical Diagnosis System"
        ],

        "certifications": [
            "Google AI Essentials",
            "Machine Learning Specialization",
            "DeepLearning.AI Generative AI"
        ]
    },

    "Backend Developer": {
        "skills": [
            "python",
            "django",
            "sql",
            "rest api"
        ],

        "projects": [
            "E-Commerce Backend",
            "Hospital Management System",
            "Inventory Management System",
            "Blog API Platform"
        ],

        "certifications": [
            "Django REST Framework",
            "PostgreSQL",
            "Docker",
            "AWS Cloud Practitioner"
        ]
    },

    "Frontend Developer": {
        "skills": [
            "html",
            "css",
            "javascript",
            "react"
        ],

        "projects": [
            "Netflix Clone",
            "Portfolio Website",
            "Task Manager",
            "E-Commerce Frontend"
        ],

        "certifications": [
            "React Developer",
            "JavaScript Advanced",
            "Frontend Development"
        ]
    },

    "Full Stack Developer": {
        "skills": [
            "django",
            "react",
            "sql",
            "git"
        ],

        "projects": [
            "Job Portal",
            "Food Delivery System",
            "Social Media Platform",
            "Learning Management System"
        ],

        "certifications": [
            "Full Stack Development",
            "AWS",
            "Docker",
            "GitHub Advanced"
        ]
    },

    "Data Analyst": {
        "skills": [
            "python",
            "sql",
            "excel",
            "power bi"
        ],

        "projects": [
            "Sales Dashboard",
            "Customer Churn Analysis",
            "Financial Analytics",
            "HR Analytics"
        ],

        "certifications": [
            "Google Data Analytics",
            "Power BI",
            "SQL Advanced"
        ]
    },

    "Android Developer": {
        "skills": [
            "java",
            "kotlin",
            "android"
        ],

        "projects": [
            "Expense Tracker",
            "College App",
            "Food Delivery App",
            "Attendance App"
        ],

        "certifications": [
            "Android Development",
            "Kotlin Programming",
            "Firebase"
        ]
    },

    "Cybersecurity Analyst": {
        "skills": [
            "networking",
            "linux",
            "security"
        ],

        "projects": [
            "Vulnerability Scanner",
            "Network Monitor",
            "Password Manager",
            "Security Dashboard"
        ],

        "certifications": [
            "Google Cybersecurity",
            "CompTIA Security+",
            "CEH"
        ]
    },

    "Cloud Engineer": {
        "skills": [
            "aws",
            "docker",
            "kubernetes"
        ],

        "projects": [
            "Cloud Resume Challenge",
            "Kubernetes Deployment",
            "Serverless App",
            "CI/CD Pipeline"
        ],

        "certifications": [
            "AWS Cloud Practitioner",
            "AWS Solutions Architect",
            "Docker"
        ]
    },

    "DevOps Engineer": {
        "skills": [
            "docker",
            "kubernetes",
            "jenkins",
            "linux"
        ],

        "projects": [
            "CI/CD Pipeline",
            "Container Deployment",
            "Monitoring Dashboard",
            "Infrastructure Automation"
        ],

        "certifications": [
            "Docker",
            "Kubernetes",
            "Jenkins",
            "AWS DevOps"
        ]
    }
}