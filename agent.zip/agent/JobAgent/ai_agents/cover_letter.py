from google import genai

client = genai.Client(
    api_key="AQ.Ab8RN6KT3Q-MKVa8lagIbZHmUkglt3CCJUf4i9pQZoRIje1njw"
)

def generate_cover_letter(
    resume_text,
    job_title,
    company
    ):
    prompt = f"""
    Create a professional cover letter.
    Candidate Resume:
    {resume_text}
    Job Title:
    {job_title}
    Company:
    {company}
    """
    try:
        response = client.models.generate_content(
        model="gemini-2.0-flash",
        contents=prompt
    )

        return response.text
    except Exception as e:
        return f"Error: {str(e)}"
