def generate_roadmap(
    career_paths,
    weaknesses
):

    roadmap = []

    month = 1

    if "REST API" in weaknesses:

        roadmap.append({

            "month": month,

            "title": "Backend Development",

            "tasks": [

                "Learn REST APIs",

                "Build Blog API using Django REST Framework"
            ]
        })

        month += 1

    if "Docker" in weaknesses:

        roadmap.append({

            "month": month,

            "title": "Containerization",

            "tasks": [

                "Learn Docker Basics",

                "Dockerize a Django Project"
            ]
        })

        month += 1

    if "AWS" in weaknesses:

        roadmap.append({

            "month": month,

            "title": "Cloud Deployment",

            "tasks": [

                "Learn AWS Fundamentals",

                "Deploy Django Project on AWS"
            ]
        })

        month += 1

    roadmap.append({

        "month": month,

        "title": "Interview Preparation",

        "tasks": [

            "Practice Technical Questions",

            "Prepare HR Answers",

            "Build Portfolio"
        ]
    })

    return roadmap