from google import genai

client = genai.Client(
    api_key="AQ.Ab8RN6KT3Q-MKVa8lagIbZHmUkglt3CCJUf4i9pQZoRIje1njw"
)

def explain_job_fit(
    resume_text,
    job_title,
    job_description
):

    prompt = f"""
    Resume:

    {resume_text}

    Job:

    {job_title}

    Description:

    {job_description}

    Explain in 5 bullet points:

    Why this job matches the candidate.
    """

    response = client.models.generate_content(
        model="gemini-2.5-flash",
        contents=prompt
    )

    return response.text