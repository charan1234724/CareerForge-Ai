from ai_agents.llm_service import ask_llm


def tailor_resume(
    resume_text,
    job_text
):

    prompt = f"""

    Analyze this resume against
    the job description.

    Resume:

    {resume_text}

    Job Description:

    {job_text}

    Give:

    1. Match Score (0-100)

    2. Missing Skills

    3. Missing Keywords

    4. ATS Improvements

    5. Resume Improvements

    Keep response professional.
    """

    return ask_llm(
        prompt
    )