from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from .models import SavedJob, Application
from .models import SavedJob


@login_required
def save_job(request):

    title = request.GET.get("title")
    company = request.GET.get("company")
    url = request.GET.get("url")

    SavedJob.objects.create(
        user=request.user,
        title=title,
        company=company,
        url=url
    )

    return redirect("saved_jobs")


@login_required
def saved_jobs(request):

    jobs = SavedJob.objects.filter(
        user=request.user
    ).order_by("-saved_at")

    return render(
        request,
        "applications/saved_jobs.html",
        {
            "jobs": jobs
        }
    )
@login_required
def apply_job(request):

    title = request.GET.get("title")
    company = request.GET.get("company")

    Application.objects.create(
        user=request.user,
        title=title,
        company=company,
        status="Applied"
    )

    return redirect("applications")
@login_required
def applications(request):

    apps = Application.objects.filter(
        user=request.user
    ).order_by("-applied_at")

    return render(
        request,
        "applications/applications.html",
        {
            "applications": apps
        }
    )
@login_required
def delete_saved_job(
    request,
    id
):

    job = SavedJob.objects.filter(
        id=id,
        user=request.user
    ).first()

    if job:
        job.delete()

    return redirect(
        "saved_jobs"
    )
@login_required
def delete_application(
    request,
    id
):

    app = Application.objects.filter(
        id=id,
        user=request.user
    ).first()

    if app:
        app.delete()

    return redirect(
        "applications"
    )