from django.contrib import admin
from django.urls import path

from django.conf import settings
from django.conf.urls.static import static
from django.urls import path, include

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include('jobs.urls')),
    path('', include('jobs.urls')),
    path('', include('resumes.urls')),
    path('', include('accounts.urls')),
    path('', include('applications.urls')),
    path(
    "",
    include("ai_agents.urls")
),
]

if settings.DEBUG:
    urlpatterns += static(
        settings.MEDIA_URL,
        document_root=settings.MEDIA_ROOT
    )
