from django.shortcuts import render

from resumes.models import Resume
from jobs.models import Job

from .matcher import calculate_match
from .job_search import search_jobs
from .real_matcher import calculate_real_match
from ai_agents.skill_gap_agent import (
    analyze_skill_gap
)
from jobs.embedding_matcher import (
    calculate_embedding_match
)

from jobs.profile_builder import (
    build_profile
)

def matched_jobs(request):

    resume = Resume.objects.last()

    if not resume:
        return render(
            request,
            "jobs/matches.html",
            {"matches": []}
        )

    resume_skills = [
        skill.name
        for skill in resume.skills.all()
    ]

    matches = []

    for job in Job.objects.all():

        job_skills = job.required_skills.split(",")

        score = calculate_match(
            resume_skills,
            job_skills
        )

        matches.append({
            "job": job,
            "score": score
        })

    matches.sort(
        key=lambda x: x["score"],
        reverse=True
    )

    return render(
        request,
        "jobs/matches.html",
        {
            "matches": matches,
            "resume_skills": resume_skills
        }
    )

def real_jobs(request):
    resume = Resume.objects.filter(
    user=request.user
    ).last()
    if not resume:

        return render(
        request,
        "jobs/real_jobs.html",
        {
            "jobs": []
        }
    )

    profile_text = build_profile(
        resume
)

    data = search_jobs()

    matched_jobs = []

    for job in data["data"][:50]:

        job_text = (

        job.get(
            "job_title",
            ""
        )

        + " "

        + job.get(
            "job_description",
            ""
        )

        ).lower()

        score = calculate_embedding_match(
        profile_text,
        job_text
    )

        matched_jobs.append({

        "title": job.get(
            "job_title",
            "Unknown"
        ),

        "company": job.get(
            "employer_name",
            "Unknown"
        ),

        "url": job.get(
            "job_apply_link",
            "#"
        ),

        "score": score,

        "job_text": job_text

    })

    matched_jobs.sort(
    key=lambda x: x["score"],
    reverse=True
)

    matched_jobs = matched_jobs[:10]

    return render(
    request,
    "jobs/real_jobs.html",
    {
        "jobs": matched_jobs
    }
)
from django.contrib.auth.decorators import login_required


@login_required
def skill_gap(request):

    resume = Resume.objects.filter(
        user=request.user
    ).last()

    if not resume:

        return render(
            request,
            "jobs/skill_gap.html",
            {
                "analysis": "No resume uploaded."
            }
        )

    job_text = request.GET.get(
        "job_text",
        ""
    )

    analysis = analyze_skill_gap(
        resume.resume_text,
        job_text
    )

    return render(
        request,
        "jobs/skill_gap.html",
        {
            "analysis": analysis
        }
    )