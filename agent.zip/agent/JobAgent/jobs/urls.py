from django.urls import path
from .views import matched_jobs, real_jobs, skill_gap

urlpatterns = [
    path(
        "matches/",
        matched_jobs,
        name="matches"
    ),

    path(
        "real-jobs/",
        real_jobs,
        name="real_jobs"
    ),
    path(
    "skill-gap/",
    skill_gap,
    name="skill_gap"
),
]