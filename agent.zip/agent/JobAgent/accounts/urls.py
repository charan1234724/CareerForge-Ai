from django.urls import path
from .dashboard import dashboard
from .views import signup

urlpatterns = [
    path(
        "signup/",
        signup,
        name="signup"
    ),
    path(
    "dashboard/",
    dashboard,
    name="dashboard"
),
]