from django.shortcuts import render
from django.contrib.auth.decorators import login_required

from resumes.models import Resume

from applications.models import (
    SavedJob,
    Application,
)

from ai_agents.resume_improver import (
    analyze_resume_improvement
)


@login_required
def dashboard(request):

    resume = Resume.objects.filter(
        user=request.user
    ).last()

    saved_jobs_count = SavedJob.objects.filter(
        user=request.user
    ).count()

    applications_count = Application.objects.filter(
        user=request.user
    ).count()

    recent_applications = (
        Application.objects.filter(
            user=request.user
        )
        .order_by("-applied_at")[:5]
    )

    skills_count = 0
    result = None

    if resume:

        skills_count = (
            resume.skills.count()
        )

        result = analyze_resume_improvement(
            resume.resume_text
        )

    return render(
        request,
        "accounts/dashboard.html",
        {
            "resume": resume,
            "saved_jobs_count": saved_jobs_count,
            "applications_count": applications_count,
            "recent_applications": recent_applications,
            "skills_count": skills_count,
            "result": result,
        }
    )